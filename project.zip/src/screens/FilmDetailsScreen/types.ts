import {Movie} from 'types/generalTypes';

export interface FilmDetailsRouteProps {
  movie: Movie;
}
