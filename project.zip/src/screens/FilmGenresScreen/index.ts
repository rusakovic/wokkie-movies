export {default} from './FilmGenresScreen';
