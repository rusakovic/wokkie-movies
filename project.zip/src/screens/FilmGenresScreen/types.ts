import {Movie} from 'types/generalTypes';

export interface GenresWithKeysType {
  genreKey: string;
  movies: Movie[];
}
