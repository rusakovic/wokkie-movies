export const DEFAULT_API_URL = 'https://wookie.codesubmit.io/movies';
