export enum TestID {
  GenresList = 'GenresList',
  PulpFiction = 'a9d94d6e-4cab-44a9-8eec-d44ad6332b6d',
  MovieDetailsScreen = 'MovieDetailsScreen',

  ButtonMovieIsHidden = 'ButtonMovieIsHidden',
  ButtonMovieIsShowed = 'ButtonMovieIsShowed',

  ButtonIsFavorite = 'ButtonIsFavorite',
  ButtonIsNotFavorite = 'ButtonIsNotFavorite',
}
