export {default} from './MovieGenreList';
