export {default} from './MovieSearchPreview';
