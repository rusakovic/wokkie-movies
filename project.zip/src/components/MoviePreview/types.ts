import {Movie} from 'types/generalTypes';

export interface MoviePreviewProps {
  movie: Movie;
}
