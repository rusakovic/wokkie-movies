export const movieIDsArrayMock = [
  'a9d94d6e-4cab-44a9-8eec-d44ad6332b6d',
  'd6822b7b-48bb-4b78-ad5e-9ba04c517ec8',
  '8de5e9be-ec40-4687-9b01-be1af3ace1d7',
];
